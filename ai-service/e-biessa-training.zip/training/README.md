# Automotive query-extraction training

This folder keeps fine-tuning separate from the runtime FastAPI service. The target is canonical JSON extraction, not memorizing listings or generating compatibility claims.

## Generate deterministic data

From `ai-service`:

```powershell
.\.venv\Scripts\python.exe training\generate_dataset.py
```

The generator creates `training/data/train.json`, `validation.json`, and `test.json`. Training rows contain only LitGPT's documented `instruction`, `input`, and `output` fields. The held-out test rows also contain a language label for evaluation. Fixed English, French, and Tunisian baseline prompts are held out from training.

## Measure the local Ollama baseline

Keep Ollama running, then execute:

```powershell
.\.venv\Scripts\python.exe training\evaluate_ollama.py --model e-biessa-qwen --limit 24
```

The report distinguishes strict canonical accuracy from normalized semantic accuracy. Fine-tuning succeeds only if it improves the held-out strict accuracy without reducing JSON validity.

Recorded pre-training baseline on all 120 held-out examples:

- JSON validity: 100%
- exact full-record accuracy: 0%
- make, model, year, and fuel accuracy: 100% each
- position accuracy: 87.5%
- canonical category accuracy: 8.3%
- canonical part-type accuracy: 13.3%

## Fine-tune with QLoRA in Lightning.ai

The Ollama GGUF is an inference artifact; do not upload it for training. In a Lightning Studio with a CUDA GPU, upload this `training` folder and run:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip litgpt 'bitsandbytes>=0.43.1'

litgpt finetune_lora Qwen/Qwen2.5-7B-Instruct \
  --data JSON \
  --data.json_path training/data/train.json \
  --data.val_split_fraction 0.1 \
  --data.mask_inputs true \
  --precision bf16-true \
  --quantize bnb.nf4 \
  --devices 1 \
  --train.micro_batch_size 1 \
  --train.global_batch_size 8 \
  --train.max_seq_length 512 \
  --train.epochs 3 \
  --eval.interval 50 \
  --out_dir out/e-biessa-qwen25-7b-qlora
```

Run a short smoke test first by appending `--train.max_steps 10`. If it completes without an out-of-memory error, remove that option and launch the full run. Lightning downloads the original Hugging Face checkpoint in the cloud; the local GGUF remains unchanged.

After training, test the adapter-backed final checkpoint:

```bash
litgpt chat out/e-biessa-qwen25-7b-qlora/final
```

Do not overwrite the baseline report. Export the trained checkpoint to an Ollama-compatible GGUF only after its held-out accuracy is better than the baseline.

## Data policy

- Keep marketplace listing contents out of the model weights; listings belong in Qdrant and are supplied at retrieval time.
- Do not include passwords, messages, phone numbers, emails, or other personal information.
- Preserve the held-out test set. Never add its exact prompts to training data.
- Review machine-generated Tunisian Arabic and automotive terminology with a fluent speaker before the final training run.
